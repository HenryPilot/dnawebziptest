'use strict';
const MANIFEST = 'flutter-app-manifest';
const TEMP = 'flutter-temp-cache';
const CACHE_NAME = 'flutter-app-cache';
const RESOURCES = {
  "assets/asset/hsbc-logo.png": "0c2269ee33c78381430e7976cc98a43a",
"assets/asset/row1_bg.png": "839e572e7f68e110e3718a03924b294e",
"assets/asset/row3_01.png": "e0169ea473fee343493b76a455b13921",
"assets/asset/row3_02.png": "fc6a1ca2839069cebe0a1d8185e26554",
"assets/asset/row3_03.png": "b2218a0132de8c00904b9a1a712c6734",
"assets/asset/row3_04.png": "e7e29733a761bdfb781d27c870d75582",
"assets/asset/team_all_in_one.png": "0c6e9c4c58ab0677afdb8ab248eaffec",
"assets/asset/T_Banjamin.png": "c508a5d571a977d7f64724e82f4946e8",
"assets/asset/T_Charlotte.png": "92b55ba246deeea008fae9b5cf7af693",
"assets/asset/T_Chris.png": "578c7c58c77f49ef7f92944c3935fb25",
"assets/asset/T_Faiza.png": "8597803204a091ed42323044fbdd27ca",
"assets/asset/T_jeffery.png": "0f20c12286f723394dcf2ace753aadb3",
"assets/asset/T_Laura.png": "00f4b25aea6a13ccd77b72fc7deae17c",
"assets/asset/T_Michael_48.png": "5100a832488a8b2ed573229d7aab0efe",
"assets/asset/T_mitesh.png": "03aa6fa52711f7db66250c45bc2052a0",
"assets/asset/T_Navin.png": "48ed7dfbcb6618aa2587c8cbcf24ed84",
"assets/asset/T_Nicola.png": "6ee8ac1406b87ed1f465dfae198a7043",
"assets/asset/T_ranil.png": "de9975dd8a9bc727ca4ba184593931d8",
"assets/asset/T_richardD.png": "c217691f7f66139886e6fecd56337561",
"assets/asset/T_rob.png": "cd34a0e7e570d7a3e1e0036dbfc45009",
"assets/asset/T_Upendra.png": "c9c9ed0d1fd3f9fdd304eae41cfad7d6",
"assets/asset/T_Yusuf.png": "b2e4bb8ba337ef01f357ec69c2a8a4c1",
"assets/asset/T__RichardB.png": "90d1fc9cb803d4346a42520217735b6d",
"assets/asset/Untitled-1_03.png": "bd1347238a30ab145fc8555c89ae4339",
"assets/asset/Untitled-1_05.png": "5a77019333c2fe19e5b05a0c8d396f59",
"assets/asset/Untitled-1_07.png": "98ad7d3639803f2540b20ad17b064f16",
"assets/asset/Untitled-1_12.png": "0fd5b203bc0d457ff99bf858a151519e",
"assets/asset/Untitled-1_13.png": "c2b63dce6eaefe76d2890764884dda2e",
"assets/asset/Untitled-1_14.png": "1ff692aaaa3e75aea821046b927cb0be",
"assets/asset/Who%2520We%2520Are%2520-%2520Our%2520News.docx%2520-%2520Shortcut.lnk": "e04b7ec1b3741efa23615474d54e929f",
"assets/asset/who_we_are_lower_bg.png": "ecde1773e02de91cf27226141d13ba46",
"assets/asset/world_map.png": "e80a4d2357323120641188c0008463b2",
"assets/AssetManifest.json": "ea2b13aac31229d11a2a5c7cceb4c894",
"assets/FontManifest.json": "bd1a78fe053be618639989cc30f43e6c",
"assets/fonts/MaterialIcons-Regular.ttf": "56d3ffdef7a25659eab6a68a3fbfaf16",
"assets/fonts/Pacifico-Regular.ttf": "9b94499ccea3bd82b24cb210733c4b5e",
"assets/fonts/UniversNextforHSBC-Bold.otf": "52331d34fcd95d328de249fd2333577f",
"assets/fonts/UniversNextforHSBC-Regular.ttf": "b8129c471236f5b55f02feada1088f93",
"assets/fonts/UniversNextforHSBC-Thin.ttf": "0930d6b344c539d34d59c9c40ac9ece4",
"assets/NOTICES": "07d55e2936f8e6c88e76786ef060e608",
"assets/packages/cupertino_icons/assets/CupertinoIcons.ttf": "115e937bb829a890521f72d2e664b632",
"assets/packages/open_iconic_flutter/assets/open-iconic.woff": "3cf97837524dd7445e9d1462e3c4afe2",
"favicon.png": "5dcef449791fa27946b3d35ad8803796",
"icons/Icon-192.png": "ac9a721a12bbc803b44f645561ecb1e1",
"icons/Icon-512.png": "96e752610906ba2a93c65f8abe1645f1",
"index.html": "e35564217760d1f2ba16d7adb4b93527",
"/": "e35564217760d1f2ba16d7adb4b93527",
"main.dart.js": "d3ecc481eca4157e2baa052533d2f713",
"manifest.json": "aef03bc5138a8e12a78ddd4b291c91d3"
};

// The application shell files that are downloaded before a service worker can
// start.
const CORE = [
  "/",
"main.dart.js",
"index.html",
"assets/LICENSE",
"assets/AssetManifest.json",
"assets/FontManifest.json"];

// During install, the TEMP cache is populated with the application shell files.
self.addEventListener("install", (event) => {
  return event.waitUntil(
    caches.open(TEMP).then((cache) => {
      // Provide a no-cache param to ensure the latest version is downloaded.
      return cache.addAll(CORE.map((value) => new Request(value, {'cache': 'no-cache'})));
    })
  );
});

// During activate, the cache is populated with the temp files downloaded in
// install. If this service worker is upgrading from one with a saved
// MANIFEST, then use this to retain unchanged resource files.
self.addEventListener("activate", function(event) {
  return event.waitUntil(async function() {
    try {
      var contentCache = await caches.open(CACHE_NAME);
      var tempCache = await caches.open(TEMP);
      var manifestCache = await caches.open(MANIFEST);
      var manifest = await manifestCache.match('manifest');

      // When there is no prior manifest, clear the entire cache.
      if (!manifest) {
        await caches.delete(CACHE_NAME);
        contentCache = await caches.open(CACHE_NAME);
        for (var request of await tempCache.keys()) {
          var response = await tempCache.match(request);
          await contentCache.put(request, response);
        }
        await caches.delete(TEMP);
        // Save the manifest to make future upgrades efficient.
        await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
        return;
      }

      var oldManifest = await manifest.json();
      var origin = self.location.origin;
      for (var request of await contentCache.keys()) {
        var key = request.url.substring(origin.length + 1);
        if (key == "") {
          key = "/";
        }
        // If a resource from the old manifest is not in the new cache, or if
        // the MD5 sum has changed, delete it. Otherwise the resource is left
        // in the cache and can be reused by the new service worker.
        if (!RESOURCES[key] || RESOURCES[key] != oldManifest[key]) {
          await contentCache.delete(request);
        }
      }
      // Populate the cache with the app shell TEMP files, potentially overwriting
      // cache files preserved above.
      for (var request of await tempCache.keys()) {
        var response = await tempCache.match(request);
        await contentCache.put(request, response);
      }
      await caches.delete(TEMP);
      // Save the manifest to make future upgrades efficient.
      await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
      return;
    } catch (err) {
      // On an unhandled exception the state of the cache cannot be guaranteed.
      console.error('Failed to upgrade service worker: ' + err);
      await caches.delete(CACHE_NAME);
      await caches.delete(TEMP);
      await caches.delete(MANIFEST);
    }
  }());
});

// The fetch handler redirects requests for RESOURCE files to the service
// worker cache.
self.addEventListener("fetch", (event) => {
  var origin = self.location.origin;
  var key = event.request.url.substring(origin.length + 1);
  // Redirect URLs to the index.html
  if (event.request.url == origin || event.request.url.startsWith(origin + '/#')) {
    key = '/';
  }
  // If the URL is not the the RESOURCE list, skip the cache.
  if (!RESOURCES[key]) {
    return event.respondWith(fetch(event.request));
  }
  event.respondWith(caches.open(CACHE_NAME)
    .then((cache) =>  {
      return cache.match(event.request).then((response) => {
        // Either respond with the cached resource, or perform a fetch and
        // lazily populate the cache. Ensure the resources are not cached
        // by the browser for longer than the service worker expects.
        var modifiedRequest = new Request(event.request, {'cache': 'no-cache'});
        return response || fetch(modifiedRequest).then((response) => {
          cache.put(event.request, response.clone());
          return response;
        });
      })
    })
  );
});

self.addEventListener('message', (event) => {
  // SkipWaiting can be used to immediately activate a waiting service worker.
  // This will also require a page refresh triggered by the main worker.
  if (event.message == 'skipWaiting') {
    return self.skipWaiting();
  }

  if (event.message = 'downloadOffline') {
    downloadOffline();
  }
});

// Download offline will check the RESOURCES for all files not in the cache
// and populate them.
async function downloadOffline() {
  var resources = [];
  var contentCache = await caches.open(CACHE_NAME);
  var currentContent = {};
  for (var request of await contentCache.keys()) {
    var key = request.url.substring(origin.length + 1);
    if (key == "") {
      key = "/";
    }
    currentContent[key] = true;
  }
  for (var resourceKey in Object.keys(RESOURCES)) {
    if (!currentContent[resourceKey]) {
      resources.add(resourceKey);
    }
  }
  return Cache.addAll(resources);
}
